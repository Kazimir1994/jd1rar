package com.gmail.aperavoznikau.part1;

import java.util.ArrayList;
import java.util.List;

public class ListService {

    private final List<String> list = new ArrayList<>();

    public synchronized void add(String message) {
        System.out.println(Thread.currentThread().getName() + " in start add method");
        synchronized (list){
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            list.add(message);
        }
        System.out.println(Thread.currentThread().getName() + " in end add method");
    }
}
