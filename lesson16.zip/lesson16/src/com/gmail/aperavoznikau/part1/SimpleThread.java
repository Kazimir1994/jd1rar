package com.gmail.aperavoznikau.part1;

public class SimpleThread extends Thread {

    private ListService listService;

    public SimpleThread(ListService listService) {
        this.listService = listService;
    }

    @Override
    public void run() {
        listService.add(getName());
    }
}
