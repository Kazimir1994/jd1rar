package com.gmail.aperavoznikau.part1;

public class Main {

    public static void main(String[] args) {
        ListService listService = new ListService();
        Thread thread = new SimpleThread(listService);
        thread.start();
        Thread thread1 = new Thread(new SimpleInterfaceThread());
        thread1.start();
    }

    public static void printMessage() {
        System.out.println("Forever!");
    }


}
