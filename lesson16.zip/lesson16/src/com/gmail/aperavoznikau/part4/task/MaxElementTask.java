package com.gmail.aperavoznikau.part4.task;

import java.util.List;
import java.util.concurrent.Callable;

public class MaxElementTask implements Callable<Integer> {

    private List<Integer> elements;

    public MaxElementTask(List<Integer> elements) {
        this.elements = elements;
    }

    @Override
    public Integer call() {
        if (elements.isEmpty()) {
            return null;
        }
        int maxElement = elements.get(0);
        for (Integer element : elements) {
            maxElement = Math.max(element, maxElement);
        }
        return maxElement;
    }
}
