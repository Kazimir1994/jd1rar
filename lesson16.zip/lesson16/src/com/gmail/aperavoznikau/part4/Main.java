package com.gmail.aperavoznikau.part4;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import com.gmail.aperavoznikau.part4.task.MaxElementTask;

public class Main {

    public static void main(String[] args) {
        ExecutorService executorService = Executors.newFixedThreadPool(2);

        List<Future<Integer>> futureTasks = new ArrayList<>();
        for (int i = 0; i < 30; i++) {
            MaxElementTask task = new MaxElementTask(Arrays.asList(5, 4, 6));
            Future<Integer> submit = executorService.submit(task);
            futureTasks.add(submit);
        }
        executorService.shutdown();

        int sum = 0;
        int count = 0;
        while (count < futureTasks.size()) {
            count = 0;
            sum = 0;
            for (Future<Integer> futureTask : futureTasks) {
                if (futureTask.isDone()) {
                    try {
                        Integer integer = futureTask.get();
                        sum += integer;
                    } catch (InterruptedException | ExecutionException e) {
                        e.printStackTrace();
                    }
                    count++;
                }
            }
        }

        System.out.println("Sum " + sum);

    }
}
