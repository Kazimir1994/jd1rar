package com.gmail.aperavoznikau.part3;

public class Deadlock {

    public static void main(String[] args) {
        String obj1 = new String("obj1");
        String obj2 = new String("obj2");

        Thread t1 = new Thread(new DeadlockThread(obj1, obj2), "t1");
        Thread t2 = new Thread(new DeadlockThread(obj2, obj1), "t2");

        t1.start();
        t2.start();
    }
}
