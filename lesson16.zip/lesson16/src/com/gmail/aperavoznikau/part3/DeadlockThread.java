package com.gmail.aperavoznikau.part3;

class DeadlockThread implements Runnable {

    private String obj1;
    private String obj2;

    public DeadlockThread(String o1, String o2) {
        this.obj1 = o1;
        this.obj2 = o2;
    }

    @Override
    public void run() {
        synchronized (obj1) {
            System.out.println("sync " + Thread.currentThread().getName() + " by " + obj1);
            try {
                Thread.sleep(800);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            synchronized (obj2) {

            }
        }
    }
}